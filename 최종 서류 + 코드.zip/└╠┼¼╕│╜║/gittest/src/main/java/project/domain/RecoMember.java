package project.domain;

public class RecoMember {

	
	private int user_no;
	private int activity_no1;
	private int activity_no2;
	private int activity_no3;
	private int activity_no4;
	private int activity_no5;
	private int activity_no6;
	private int activity_no7;
	private int activity_no8;
	private int activity_no9;
	private int activity_no10;
	
	//getter, setter
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public int getActivity_no1() {
		return activity_no1;
	}
	public void setActivity_no1(int activity_no1) {
		this.activity_no1 = activity_no1;
	}
	public int getActivity_no2() {
		return activity_no2;
	}
	public void setActivity_no2(int activity_no2) {
		this.activity_no2 = activity_no2;
	}
	public int getActivity_no3() {
		return activity_no3;
	}
	public void setActivity_no3(int activity_no3) {
		this.activity_no3 = activity_no3;
	}
	public int getActivity_no4() {
		return activity_no4;
	}
	public void setActivity_no4(int activity_no4) {
		this.activity_no4 = activity_no4;
	}
	public int getActivity_no5() {
		return activity_no5;
	}
	public void setActivity_no5(int activity_no5) {
		this.activity_no5 = activity_no5;
	}
	public int getActivity_no6() {
		return activity_no6;
	}
	public void setActivity_no6(int activity_no6) {
		this.activity_no6 = activity_no6;
	}
	public int getActivity_no7() {
		return activity_no7;
	}
	public void setActivity_no7(int activity_no7) {
		this.activity_no7 = activity_no7;
	}
	public int getActivity_no8() {
		return activity_no8;
	}
	public void setActivity_no8(int activity_no8) {
		this.activity_no8 = activity_no8;
	}
	public int getActivity_no9() {
		return activity_no9;
	}
	public void setActivity_no9(int activity_no9) {
		this.activity_no9 = activity_no9;
	}
	public int getActivity_no10() {
		return activity_no10;
	}
	public void setActivity_no10(int activity_no10) {
		this.activity_no10 = activity_no10;
	}
	
	
	// 생성자
	
	
	public RecoMember(int user_no, int activity_no1, int activity_no2, int activity_no3, int activity_no4,
			int activity_no5, int activity_no6, int activity_no7, int activity_no8, int activity_no9,
			int activity_no10) {
		super();
		this.user_no = user_no;
		this.activity_no1 = activity_no1;
		this.activity_no2 = activity_no2;
		this.activity_no3 = activity_no3;
		this.activity_no4 = activity_no4;
		this.activity_no5 = activity_no5;
		this.activity_no6 = activity_no6;
		this.activity_no7 = activity_no7;
		this.activity_no8 = activity_no8;
		this.activity_no9 = activity_no9;
		this.activity_no10 = activity_no10;
	}
	
	public RecoMember() {
		super();
	}
	
	public RecoMember(int user_no) {
		super();
		this.user_no = user_no;
	}
	
	

	
}
